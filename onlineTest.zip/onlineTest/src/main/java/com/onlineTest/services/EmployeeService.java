package com.onlineTest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineTest.entities.Employee;
import com.onlineTest.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	public Employee saveEmployee(Employee employee) {
		employee = employeeRepository.save(employee);
		return employee;
	}
	
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}
	
	public Employee getEmployeeById(int id) {
		return employeeRepository.findById(id).get();
	}
	
	public Employee updateEmployee(int id, Employee employee) {
		Employee tempEmployee = employeeRepository.findById(id).get();
		tempEmployee.setEmployeeName(employee.getEmployeeName());
		tempEmployee.setDepartment(employee.getDepartment());
		tempEmployee.setSalary(employee.getSalary());
		return employeeRepository.save(tempEmployee);
	}
	
	public void deleteEmployee(int id) {
		employeeRepository.deleteById(id);
	}
	
}
